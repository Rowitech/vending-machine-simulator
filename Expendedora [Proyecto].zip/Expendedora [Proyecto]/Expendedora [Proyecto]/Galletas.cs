﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedora__Proyecto_
{
    public class Galletas : Producto
    {
        public Galletas()
        {
        }

        public Galletas(int id, string categoria, int i) : base(id, categoria, i)
        {
        }

        public Galletas(int id, string nombre, string marca, int precio, string categoria, int cantidad) : base(id, nombre, marca, precio, categoria, cantidad)
        {
        }
    }
}
