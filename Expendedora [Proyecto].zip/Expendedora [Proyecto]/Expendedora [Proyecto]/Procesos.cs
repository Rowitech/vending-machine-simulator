﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedora__Proyecto_
{
    public interface Procesos
    {
        int getGanancias();
        int getCambio(int precio, int credito);
        Producto getProducto(int id);
        void agregarProductos(int id, int cantidad);
        void quitarProductos(int id, int cantidad);
        void agregarProducto(int id);
        void quitarProducto(int id);
        void editarProducto(int id, Producto p);
        void guardar();
    }
}
