﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedora__Proyecto_
{
    public class Frituras : Producto
    {
        public Frituras()
        {
        }

        public Frituras(int id, string categoria, int i) : base(id, categoria, i)
        {
        }

        public Frituras(int id, string nombre, string marca, int precio, string categoria, int cantidad) : base(id, nombre, marca, precio, categoria, cantidad)
        {
        }
    }
}
