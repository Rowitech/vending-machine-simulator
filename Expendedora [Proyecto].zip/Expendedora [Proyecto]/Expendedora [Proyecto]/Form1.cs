﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Expendedora__Proyecto_
{
    
    public partial class Form1 : Form
    {
        private Maquina Maquina;
        private StreamReader reader;

        public Form1()
        {
            InitializeComponent();
            Maquina = new Maquina();
            cargarMaquina();
        }

        private void cargarMaquina()
        {
            try
            {
                string ruta = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                reader = new StreamReader(ruta + "\\Maquina.txt");
                String line;
                line = reader.ReadLine();
                if (line != null)
                {
                    Maquina.setCreditoInicial(int.Parse(line));
                    Maquina.setCredito(int.Parse(line));
                    line = reader.ReadLine();
                    while (line != null)
                    {
                        switch (line)
                        {
                            case "#":
                                int[] IDS = new int[6];
                                IDS[0] = int.Parse(reader.ReadLine());
                                IDS[1] = int.Parse(reader.ReadLine());
                                IDS[2] = int.Parse(reader.ReadLine());
                                IDS[3] = int.Parse(reader.ReadLine());
                                IDS[4] = int.Parse(reader.ReadLine());
                                IDS[5] = int.Parse(reader.ReadLine());
                                Maquina.setIDS(IDS);
                                break;
                            case "-":
                                Producto p = new Producto();
                                p.setID(int.Parse(reader.ReadLine()));
                                p.setNombre(reader.ReadLine());
                                p.setMarca(reader.ReadLine());
                                p.setPrecio(int.Parse(reader.ReadLine()));
                                p.setCategoria(reader.ReadLine());
                                p.setCantidad(int.Parse(reader.ReadLine()));
                                p.setIndex(int.Parse(reader.ReadLine()));
                                Maquina.getProductos().Add(p);
                                break;
                        }
                        line = reader.ReadLine();
                    }
                }

                Maquina.Nueva = false;
                reader.Close();
            }
            catch(Exception e)
            {
                MessageBox.Show("" + e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label3.Text = "";
            tabControl1.SelectedIndex = 0;
            Empleado eform = new Empleado(Maquina);
            eform.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(Maquina.Nueva == false)
            {
                tabControl1.SelectedIndex = 0;
                Persona pform = new Persona(Maquina);
                pform.Show();
            }
            else{
                label3.Text = "P r i m e r o  i n i c i a l i z e\nl a  m á q u i n a\ne n  e l  " +
                    "m o d o  E m p l e a d o";
            }
            
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.ForeColor = Color.White;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            button3.ForeColor = Color.White;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            button4.ForeColor = Color.White;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.ForeColor = Color.FromArgb(0, 255, 249);
        }
    }
}
