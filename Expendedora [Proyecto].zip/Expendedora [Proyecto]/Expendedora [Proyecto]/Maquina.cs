﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Expendedora__Proyecto_
{
    public class Maquina : Procesos
    {
        private List<Producto> Productos;
        private int CreditoInicial;
        private int Credito;
        private int[] IDS;
        private StreamWriter writer;
        public Boolean Nueva;

        public Maquina()
        {
            Productos = new List<Producto>();
            CreditoInicial = 0;
            Credito = 0;
            IDS = new int[6];
            Nueva = true;
        }

        public void setProductos(List<Producto> productos)
        {
            Productos = productos;
        }

        public List<Producto> getProductos()
        {
            return Productos;
        }

        public void setCreditoInicial(int credito)
        {
            CreditoInicial = credito;
        }

        public int getCreditoInicial()
        {
            return CreditoInicial;
        }

        public int getCredito()
        {
            return Credito;
        }

        public void setCredito(int credito)
        {
            Credito = credito;
        }

        public void setIDS(int[] ids)
        {
            IDS = ids;
        }

        public int[] getIDS()
        {
            return IDS;
        }

        
        public int getGanancias()
        {
            return Credito - CreditoInicial;
        }

        public int getCambio(int precio, int credito)
        {
            return credito - precio;
        }

        public Producto getProducto(int id)
        {
            foreach (Producto p in Productos)
            {
                if (p.getID() == id)
                {
                    return p;
                }
            }
            return null;
        }

        public void agregarProductos(int i, int cantidad)
        {
            Productos[i].setCantidad(Productos[i].getCantidad() + cantidad);
        }

        public void agregarProducto(int i)
        {
            Productos[i].setCantidad(Productos[i].getCantidad() + 1);
            guardar();
        }

        public void quitarProducto(int i)
        {
            
            if(Productos[i].getCantidad() > 0)
            {
                Productos[i].setCantidad(Productos[i].getCantidad() - 1);
            }
            guardar();
        }

        public void editarProducto(int id, Producto p)
        {
            Producto pd = getProducto(id);
            pd.setNombre(p.getNombre());
            pd.setID(p.getID());
            pd.setMarca(p.getMarca());
            pd.setPrecio(p.getPrecio());
            pd.setCategoria(p.getCategoria());
            pd.setCantidad(p.getCantidad());
        }

        public void quitarProductos(int id, int cantidad)
        {
            Producto p = getProducto(id);
            if(cantidad <= p.getCantidad() && cantidad > 0)
            {
                p.setCantidad(p.getCantidad() - cantidad);
            }

        }

        public void guardar()
        {
            try
            {
                string ruta = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                writer = new StreamWriter(ruta + "\\Maquina.txt");
                writer.WriteLine(Credito);
                writer.WriteLine("#");
                writer.WriteLine(IDS[0]);
                writer.WriteLine(IDS[1]);
                writer.WriteLine(IDS[2]);
                writer.WriteLine(IDS[3]);
                writer.WriteLine(IDS[4]);
                writer.WriteLine(IDS[5]);
                foreach(Producto p in Productos)
                {
                    writer.WriteLine("-");
                    writer.WriteLine(p.getID());
                    writer.WriteLine(p.getNombre());
                    writer.WriteLine(p.getMarca());
                    writer.WriteLine(p.getPrecio());
                    writer.WriteLine(p.getCategoria());
                    writer.WriteLine(p.getCantidad());
                    writer.WriteLine(p.getIndex());
                }
                writer.Close();
            }
            catch(Exception e)
            {
                MessageBox.Show("" + e);
            }
        }
    }
}
