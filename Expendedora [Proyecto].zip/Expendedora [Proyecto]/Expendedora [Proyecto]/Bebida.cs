﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedora__Proyecto_
{
    public class Bebida : Producto
    {
        public Bebida()
        {
        }

        public Bebida(int id, string categoria, int i) : base(id, categoria, i)
        {
        }

        public Bebida(int id, string nombre, string marca, int precio, string categoria, int cantidad) : base(id, nombre, marca, precio, categoria, cantidad)
        {
        }
    }
}
