﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expendedora__Proyecto_
{
    public partial class Persona : Form
    {
        private Maquina Maquina;
        private int Credito;
        private int ID;
        private int c;
        private Producto Producto;
        private Boolean S;

        public Persona(Maquina m)
        {
            InitializeComponent();
            Maquina = m;
            Credito = 0;
            c = 0;
            S = false;
            cargarProductos();
        }

        private void actualizarForm()
        {
            cargarImagenes();
            cargarIDS();
        }

        private void actualizarForm(object sender, EventArgs e)
        {
            cargarImagenes();
            cargarIDS();
        }
        private void cargarProductos()
        {
            cargarImagenes();
            cargarIDS();
        }

        private void cargarIDS()
        {
            label1.Text = "" + Maquina.getIDS()[0];
            label2.Text = "" + Maquina.getIDS()[1];
            label3.Text = "" + Maquina.getIDS()[2];
            label4.Text = "" + Maquina.getIDS()[3];
            label5.Text = "" + Maquina.getIDS()[4];
            label6.Text = "" + Maquina.getIDS()[5];
        }

        private void cargarImagenes()
        {
            if(Maquina.getProductos()[0].getCantidad() > 0)
            {
                pictureBox1.Image = imageList1.Images[0];
            }
            else
            {
                pictureBox1.Image = null;
            }
            if (Maquina.getProductos()[1].getCantidad() > 0)
            {
                pictureBox2.Image = imageList1.Images[1];
            }
            else
            {
                pictureBox2.Image = null;
            }
            if (Maquina.getProductos()[2].getCantidad() > 0)
            {
                pictureBox3.Image = imageList1.Images[2];
            }
            else
            {
                pictureBox3.Image = null;
            }
            if (Maquina.getProductos()[3].getCantidad() > 0)
            {
                pictureBox4.Image = imageList1.Images[3];
            }
            else
            {
                pictureBox4.Image = null;
            }
            if (Maquina.getProductos()[4].getCantidad() > 0)
            {
                pictureBox5.Image = imageList1.Images[4];
            }
            else
            {
                pictureBox5.Image = null;
            }
            if (Maquina.getProductos()[5].getCantidad() > 0)
            {
                pictureBox6.Image = imageList1.Images[5];
            }
            else
            {
                pictureBox6.Image = null;
            }
        }

        private void seleccionarProducto(int n)
        {
            if(c == 0)
            {
                label7.Text = "";
            }
            c++;
            if (c < 3)
            {
                label7.Text = label7.Text + n;
            }
            else
            {
                label7.Text = label7.Text + n;
                ID = int.Parse(label7.Text);
                label7.Text = "";
                Producto = Maquina.getProducto(ID);
                if (Producto != null)
                {
                    if(Producto.getCantidad() > 0)
                    {
                        pictureBox7.Image = imageList1.Images[Producto.getIndex()];
                        S = true;
                        label7.Text = "$" + Producto.getPrecio();
                    }
                    else
                    {
                        label7.Text = "Producto agotado...";
                    }
                }
                else
                {
                    label7.Text = "Ingrese un ID valido...";
                }
                c = 0;
            }
        }

        private void comprarProducto(object sender, EventArgs e)
        {
            if (S == true)
            {
                if (Credito >= Producto.getPrecio())
                {
                    Maquina.setCredito(Maquina.getCredito() + Credito);
                    Producto.setCantidad(Producto.getCantidad() - 1);
                 
                    if(Credito > Producto.getPrecio())
                    {
                        int cambio = Maquina.getCambio(Producto.getPrecio(), Credito);
                        label7.Text = "Cambio: $" + cambio;
                        Maquina.setCredito(Maquina.getCredito() - cambio);
                    }
                    Maquina.guardar();
                    Credito = 0;
                    pictureBox7.Image = null;
                    S = false;
                    Producto = null;
                    actualizarForm(sender, e);
                }
                else
                {
                    label7.Text = "Credito insuficiente\ndeposite $" + (Producto.getPrecio() - Credito);
                }
            }
            else
            {
                    label7.Text = "Seleccione un producto...";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            seleccionarProducto(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            seleccionarProducto(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            seleccionarProducto(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            seleccionarProducto(4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            seleccionarProducto(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            seleccionarProducto(6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            seleccionarProducto(7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            seleccionarProducto(8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            seleccionarProducto(9);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            seleccionarProducto(0);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Credito += 1;
            label7.Text = "$" + Credito;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Credito += 5;
            label7.Text = "$" + Credito;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Credito += 10;
            label7.Text = "$" + Credito ;
        }

        private void Persona_Load(object sender, EventArgs e)
        {
            label7.Text = "Deposite o \n escriba un ID...";
        }
    }
}
