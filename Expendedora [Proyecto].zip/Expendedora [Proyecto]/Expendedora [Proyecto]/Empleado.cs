﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expendedora__Proyecto_
{
    public partial class Empleado : Form
    {
        private Maquina Maquina;
        private int Editando;

        public Empleado(Maquina m)
        {
            InitializeComponent();
            Maquina = m;
            if (Maquina.Nueva) { cargarMaquina(); }
            cargarImagenes();
            cargarIDS();
            cargarCantidades();
        }

        private void cargarMaquina()
        {
            asignarIDS_DEFAULT();
            inicializarProductos();
            Maquina.Nueva = false;
        }

        private void actualizarForm(object sender, EventArgs e)
        {
            cargarImagenes();
            cargarIDS();
            cargarCantidades();
        }

        private void inicializarProductos()
        {
            Maquina.getProductos().Add(new Frituras(Maquina.getIDS()[0], "Frituras", 0));
            Maquina.getProductos().Add(new Frituras(Maquina.getIDS()[1], "Frituras", 1));
            Maquina.getProductos().Add(new Galletas(Maquina.getIDS()[2], "Galletas", 2));
            Maquina.getProductos().Add(new Galletas(Maquina.getIDS()[3], "Galletas", 3));
            Maquina.getProductos().Add(new Bebida(Maquina.getIDS()[4], "Bebidas", 4));
            Maquina.getProductos().Add(new Bebida(Maquina.getIDS()[5], "Bebidas", 5));
        }

        private void aplicarCambios(int i)
        {
            if (validarID())
            {
                int id2 = int.Parse(textBox1.Text);
                Maquina.getIDS()[i] = id2;
                Maquina.getProductos()[i].setID(id2);
            }
            
            Maquina.getProductos()[i].setNombre(textBox2.Text);
            Maquina.getProductos()[i].setMarca(textBox3.Text);
            try
            {
                int precio = int.Parse(textBox4.Text);
                Maquina.getProductos()[i].setPrecio(precio);
            }
            catch
            {
                MessageBox.Show("No se guardó el precio, escriba un número entero", "Precio inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            try
            {
                int cantidad = int.Parse(textBox5.Text);
                Maquina.getProductos()[i].setCantidad(cantidad);
            }
            catch
            {
                MessageBox.Show("No se guardó la cantidad, escriba un número entero",
                    "Cantidad inválida", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Maquina.guardar();
            tabControl1.SelectedIndex = 2;
        }

       

        private void editarProductos(int i)
        {
            Editando = i;
            pictureBox7.Image = imageList1.Images[i];
            textBox1.Text = "" + Maquina.getProductos()[i].getID();
            textBox2.Text = Maquina.getProductos()[i].getNombre();
            textBox3.Text = Maquina.getProductos()[i].getMarca();
            textBox4.Text = "" + Maquina.getProductos()[i].getPrecio();
            textBox5.Text = "" + Maquina.getProductos()[i].getCantidad();
            comboBox1.Text = Maquina.getProductos()[i].getCategoria();
            button19.Visible = false;
            tabControl1.SelectedIndex = 3;

        }

        private void asignarIDS_DEFAULT()
        {
            Maquina.getIDS()[0] = 100;
            Maquina.getIDS()[1] = 101;
            Maquina.getIDS()[2] = 200;
            Maquina.getIDS()[3] = 201;
            Maquina.getIDS()[4] = 300;
            Maquina.getIDS()[5] = 301;
        }

        private void cargarIDS()
        {
            label1.Text = "" + Maquina.getIDS()[0];
            label8.Text = "" + Maquina.getIDS()[1];
            label4.Text = "" + Maquina.getIDS()[2];
            label10.Text = "" + Maquina.getIDS()[3];
            label6.Text = "" + Maquina.getIDS()[4];
            label12.Text = "" + Maquina.getIDS()[5];
        }

        private void cargarCantidades()
        {
            label2.Text = "" + Maquina.getProductos()[0].getCantidad();
            label7.Text = "" + Maquina.getProductos()[1].getCantidad();
            label3.Text = "" + Maquina.getProductos()[2].getCantidad();
            label9.Text = "" + Maquina.getProductos()[3].getCantidad();
            label5.Text = "" + Maquina.getProductos()[4].getCantidad();
            label11.Text = "" + Maquina.getProductos()[5].getCantidad();
        }

        private void cargarImagenes()
        {
            pictureBox1.Image = imageList1.Images[0];
            pictureBox4.Image = imageList1.Images[1];
            pictureBox2.Image = imageList1.Images[2];
            pictureBox5.Image = imageList1.Images[3];
            pictureBox3.Image = imageList1.Images[4];
            pictureBox6.Image = imageList1.Images[5];
        }

        private void cargarEstado()
        {
            label20.Text = "Crédito inicial: $" + Maquina.getCreditoInicial() + "\n" +
                "Crédito actual: $" + Maquina.getCredito() + "\n" + "Ganancias: $" +
                Maquina.getGanancias();
        }

        private Boolean validarID()
        {
            try
            {
                int ID = int.Parse(textBox1.Text);
                if (ID > 99 && ID < 1000)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("El ID debe ser un número de 3 dígitos", "ID inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show("El ID debe ser un número de 3 dígitos", "ID inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
            return false;
        }
        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.White;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.ForeColor = Color.White;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            button3.ForeColor = Color.White;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            button4.ForeColor = Color.White;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            button5.ForeColor = Color.White;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            button6.ForeColor = Color.White;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.ForeColor = Color.White;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button8_MouseEnter(object sender, EventArgs e)
        {
            button8.ForeColor = Color.White;
        }

        private void button8_MouseLeave(object sender, EventArgs e)
        {
            button8.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button9_MouseEnter(object sender, EventArgs e)
        {
            button9.ForeColor = Color.White;
        }

        private void button9_MouseLeave(object sender, EventArgs e)
        {
            button9.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button10_MouseEnter(object sender, EventArgs e)
        {
            button10.ForeColor = Color.White;
        }

        private void button10_MouseLeave(object sender, EventArgs e)
        {
            button10.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button11_MouseEnter(object sender, EventArgs e)
        {
            button11.ForeColor = Color.White;
        }

        private void button11_MouseLeave(object sender, EventArgs e)
        {
            button11.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button12_MouseEnter(object sender, EventArgs e)
        {
            button12.ForeColor = Color.White;
        }

        private void button12_MouseLeave(object sender, EventArgs e)
        {
            button12.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button13_MouseEnter(object sender, EventArgs e)
        {
            button13.ForeColor = Color.White;
        }

        private void button13_MouseLeave(object sender, EventArgs e)
        {
            button13.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button14_MouseEnter(object sender, EventArgs e)
        {
            button14.ForeColor = Color.White;
        }

        private void button14_MouseLeave(object sender, EventArgs e)
        {
            button14.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button15_MouseEnter(object sender, EventArgs e)
        {
            button15.ForeColor = Color.White;
        }

        private void button15_MouseLeave(object sender, EventArgs e)
        {
            button15.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button16_MouseEnter(object sender, EventArgs e)
        {
            button16.ForeColor = Color.White;
        }

        private void button16_MouseLeave(object sender, EventArgs e)
        {
            button16.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button17_MouseEnter(object sender, EventArgs e)
        {
            button17.ForeColor = Color.White;
        }

        private void button17_MouseLeave(object sender, EventArgs e)
        {
            button17.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void button18_MouseEnter(object sender, EventArgs e)
        {
            button18.ForeColor = Color.White;
        }

        private void button18_MouseLeave(object sender, EventArgs e)
        {
            button18.ForeColor = Color.FromArgb(0, 255, 249);
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(0);
            cargarCantidades();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(0);
            cargarCantidades();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(1);
            cargarCantidades();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(1);
            cargarCantidades();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(2);
            cargarCantidades();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(2);
            cargarCantidades();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(3);
            cargarCantidades();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(3);
            cargarCantidades();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(4);
            cargarCantidades();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(4);
            cargarCantidades();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Maquina.agregarProducto(5);
            cargarCantidades();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Maquina.quitarProducto(5);
            cargarCantidades();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            aplicarCambios(Editando);
            actualizarForm(sender, e);
        }

        

        private void button20_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
            button19.Visible = false;
            cargarIDS();
            cargarCantidades();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            editarProductos(0);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            editarProductos(1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            editarProductos(2);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            editarProductos(3);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            editarProductos(4);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            editarProductos(5);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            button19.Visible = true;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            cargarEstado();
            tabControl1.SelectedIndex = 1;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button21_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }
    }
}