﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedora__Proyecto_
{
    public class Producto
    {
        private int ID;
        private String Nombre;
        private String Marca;
        private int Precio;
        private String Categoria;
        private int Cantidad;
        private int I;
        
        public Producto()
        {
            ID = 0;
            Nombre = "Sin asignar";
            Marca = "Sin asignar";
            Precio = 0;
            Categoria = "Sin asignar";
            Cantidad = 0;
        }

        public Producto(int id, String categoria, int i)
        {
            ID = id;
            Nombre = "Sin asignar";
            Marca = "Sin asignar";
            Precio = 0;
            Categoria = categoria;
            Cantidad = 0;
            I = i;
        }

        public Producto(int id, String nombre, String marca, int precio, String categoria, int cantidad)
        {
            ID = id;
            Nombre = nombre;
            Marca = marca;
            Precio = precio;
            Categoria = categoria;
            Cantidad = cantidad;
        }

        public void setID(int id)
        {
            ID = id;
        }

        public int getID()
        {
            return ID;
        }

        public void setNombre(String nombre)
        {
            Nombre = nombre;
        }

        public String getNombre()
        {
            return Nombre;
        }

        public void setMarca(String marca)
        {
            Marca = marca;
        }

        public String getMarca()
        {
            return Marca;
        }

        public void setPrecio(int precio)
        {
            Precio = precio;
        }

        public int getPrecio()
        {
            return Precio;
        }

        public void setCategoria(String categoria)
        {
            Categoria = categoria;
        }

        public String getCategoria()
        {
            return Categoria;
        }

        public void setCantidad(int cantidad)
        {
            Cantidad = cantidad;
        }

        public int getCantidad()
        {
            return Cantidad;
        }

        public void setIndex(int i)
        {
            I = i;
        }

        public int getIndex()
        {
            return I;
        }

    }
}
